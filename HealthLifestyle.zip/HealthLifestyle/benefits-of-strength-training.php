<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Health & Lifestyle</title>
    
    <link rel = "stylesheet" href = "home2.css">
    <link rel = "stylesheet" href = "normalize.css">
     <link rel = "stylesheet" href = "content.css">
    
</head>

    
<body class="center">
   
    
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
    
    <div class="headersection">
       
        
           <nav id="hor_menu">
            <ul class="hor_menu_ul">
                <li><a href="Health&Travel.html" class="current"><b>HOME</b></a></li>
                <li><a href="health.html"><b>HEALTH</b></a></li>
                <li><a href="fitness.html"><b>FITNESS</b></a></li>
                <li><a href="Calculator.html"><b>B.M.R CALCULATOR </b></a></li>
                <li><a href="login.php"><b>SIGNOUT</b></a></li>
            </ul>
        </nav>
            
            <div id="heading">
                <h1><b>Health & Lifestyle</b></h1>
            </div>
            
         
            
    </div>
    <main>
       <h1>5 Benefits of Strength Training</h1>
       <img src="deadlift.jpeg" width = "70%;" height="500px;">
       <p>
           Strength training can help you get stronger and look and feel better with just a few short sessions each week. You can do strength training with free weights such as barbells and dumbbells, weight machines, or with no equipment at all.
<br>
Exercises that use your body for resistance include:</p>
      <ul>
          <li><p>Abdominal crunches</p></li>
          <li><p>Lunges</p></li>
          <li><p>Pushups</p></li>
          <li><p>Squats</p></li>
          <li><p>Step exercises</p></li>
      </ul>
       <p>Resistance bands and tubes can be used with:</p>
       <ul>
           <li><p>Arm curls</p></li>
           <li><p>Kicks</p></li>
           <li><p>Squats</p></li>
           <li><p>Other exercises</p></li>
       </ul>
       <h2>Strength-training tips</h2>
       <ul>
           <li><p>The American Heart Association recommends strength training at least twice a week.</p></li>
           <li><p>You may want to consult with a fitness professional to learn the right way to do each exercise.</p></li>
           <li><p>Doing each exercise 8 to 12 times is usually enough to work your muscles.</p></li>
           <li><p>You know you’re doing enough work if your muscles are so tired you can barely get through the 12th repetition.</p></li>
           <li><p>Start slowly, and gradually increase the resistance or weight as the exercises become easier.</p></li>
       </ul>
       <h2>
           Benefits
       </h2>
       <p>Men and women of all ages can benefit from strength training, but get a doctor’s OK before beginning, especially if you haven’t exercised in a while.
<br>
Two or three 20- or 30-minute strength training sessions every week can result in significant health benefits:</p>
   <ol>
       <li>
           <h3>Increased muscle mass: </h3>
           <p>Muscle mass naturally decreases with age, but strength training can help reverse the trend.</p>
       </li>
       <li>
           <h3>Stronger bones:</h3>
           <p>
               Strength training increases bone density and reduces the risk of fractures.
           </p>
       </li>
       <li>
           <h3>Joint flexibility:</h3>
           <p>
               Strength training helps joints stay flexible and can reduce the symptoms of arthritis.
           </p>
       </li>
       <li>
           <h3>Weight control:</h3>
           <p>
              As you gain muscle, your body begins to burn calories more easily, making it easier to control your weight. 
           </p>
       </li>
       <li>
           <h3>Balance: </h3>
           <p>
           Strengthening exercises can increase flexibility and balance as people age, reducing falls and injuries.    
           </p>
       </li>
   </ol>
    </main>
    <br>
    <center><div class="fb-like" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div></center>
    <center><div class="fb-comments" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-numposts="10" data-width=""></div></center>
    <footer>
        
           <h3>Health & Lifestyle</h3> 
        
    </footer>
    
     

</body>
</html>