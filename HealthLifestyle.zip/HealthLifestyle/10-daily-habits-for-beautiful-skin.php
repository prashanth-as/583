<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Health & Lifestyle</title>
    
    <link rel = "stylesheet" href = "home2.css">
    <link rel = "stylesheet" href = "normalize.css">
     <link rel = "stylesheet" href = "content.css">
    
</head>

    
<body class="center">
   
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   
    
    
    
    <div class="headersection">
       
        
           <nav id="hor_menu">
            <ul class="hor_menu_ul">
                <li><a href="Health&Travel.html" class="current"><b>HOME</b></a></li>
                <li><a href="health.html"><b>HEALTH</b></a></li>
                <li><a href="fitness.html"><b>FITNESS</b></a></li>
                <li><a href="Calculator.html"><b>B.M.R CALCULATOR </b></a></li>
                <li><a href="login.php"><b>SIGNOUT</b></a></li>
            </ul>
        </nav>
            
            <div id="heading">
                <h1><b>Health & Lifestyle</b></h1>
            </div>
            
         
            
    </div>
    
    <main>
       <h1>Top 10 daily habits for beautiful, healthy skin</h1>
        <img src="lemonade.jpeg" width="80%;" height="500px";>
           <p>
            Many people spend a fortune on cosmetics and skin care products hoping to achieve a good complexion. What they fail to realize, however, is that healthy and beautiful skin begins with a good skincare routine.
<br>
A study on the evolving role of skincare revealed this fact. In the research it was found that one’s daily skin care routine has a positive impact on the overall quality of a person’s complexion, especially if it is supported by effective products.
<br>
To help you on your quest for a beautiful and radiant complexion, here are 10 daily skin care habits that you should practice for healthy, radiant skin:
       <br>
        </p>
        
        <ol>
            <li><h3>Drink plenty of water</h3>
            <p>Drinking tons of water is not only the most basic skin care habit but a key habit for maintaining general physical health as well. The cells in our body are mostly made up of water and water plays a critical role in maintaining physiological balance. Considering these facts alone, scientists have long explored the association between water and healthy complexion.
<br>
Drinking water will not only satiate your thirst but will keep your skin properly hydrated as well. One recent study published in the Journal of Clinical, Cosmetic and Investigational Dermatology supports the skin-hydrating effects of drinking plenty of water.
<br>
In the clinical trial, 49 healthy women were grouped in two. The subjects in one group were made to drink at least 5.2 liters of water a day while the other group only drank less than 3.2 liters of water daily. After observing and testing the subject’s skin hydration for a month, the researchers concluded that consuming a high volume of water daily significantly increases the hydration level of the skin.
<br>
Well-hydrated skin is clear with barely visible pores, almost no imperfections, and radiant. So instead of consuming coffee, juice, or other sweetened drinks, it's best to drink water. Apart from its skin benefits, water is free of calories and drinking more of it can help you skip drinks that are full of calories, thus helping you maintain a healthy weight. 
           <br></p>
            </li>
            <li><h3>Apply Sunscreen</h3>
            <p>
                 Sunscreen is any substance or product that protects your skin from the damaging effects of sun’s ultraviolet rays. While the sun’s rays can make you feel more energetic and attractive when you get a tan, you should avoid going out without wearing sunscreen.
<br>
Exposure to the sun’s ultraviolet (UV) rays negatively impacts the condition of your skin. In fact, most of the signs that are associated with skin aging are more often effects of prolonged exposure to sunlight that one’s actual age.
<br>
UV rays damage the skin’s elastic and collagen tissue which results in skin sagging, stretching, and wrinkles. It also causes freckles, skin discoloration, age spots, and even skin cancer. Imagine what your skin must go through when you go out under the sun without sunscreen protection.
<br>
For many years, sunscreen has been known primarily for effectively protecting the skin from developing premature signs of skin aging. A recent study, however, revealed that continuous application of sunscreen even provides beneficial effects on the photoaged skin (or damaged skin due to sun exposure). Researchers discovered that subjects who continuously wear sunscreen for 18 months experience significant improvement in their skin condition.
<br>
Note, however, that sunscreen only works if you choose the right one and if you apply it correctly. The American Academy of Dermatology (AAD) recommends a sunscreen product with SPF of 30 or higher, water-resistant, and provides protection against both UVA and UVB rays. Make sure to apply a generous amount of sunscreen to all exposed skin 15 minutes before you go out and to reapply every two hours to stay protected.
    <br>        </p>
            </li>
            <li><h3>
                Eat healthy
            </h3>
            <p>
               Your skin condition is a reflection of what is going on inside your body, which means to have a gorgeous and radiant complexion, you should properly nourish your body. This fact had long been established as many nutrition experts have shown the positive connection between good nutrition and young-looking skin.
<br>
Given this fact, you should include eating skin-friendly foods in your skin care routine. Such foods include fruits and vegetables that are rich in vitamin C. This vitamin is known for its potent antioxidant that protects the skin from harmful effects of free radicals. Vitamin C is also known to promote faster skin healing and in improving skin texture.
<br>
Other nutrients that will do wonders for your skin also include vitamins A, E, and K, selenium, omega-3, zinc, and monounsaturated and polyunsaturated fats (good fats). So, the next time you create your menu plan, make sure to include healthy servings of foods packed with these nutrients.
           <br>
            </p>
            </li>
            <li><h3>
                Take beauty supplements
            </h3>
            <p>
                Eating your way to a fabulous skin is effective; however, you must admit that it is difficult to consume all the nutrients your skin needs from the food you eat alone. Your skin is the largest organ of your body, which is why it demands more vitamins and minerals to stay healthy.
<br>
Your skin is readily exposed to numerous environmental factors that cause premature skin aging. So, apart from increasing your daily vegetable and fruit intake, it can be helpful to take supplements that benefit the skin. Popular supplements for skin include multivitamins especially ones with vitamin E and biotin, antioxidants like resveratrol and hydration agents like hyaluronic acid and collagen.
<br>
Many researchers showed that both oral and topical beauty supplements can help improve the quality and health of your skin. One study on the effects of an antioxidant supplement on skin radiance of women revealed positive effects. The women who underwent the trial have reduced skin imperfections, increased skin firmness, and more glowing skin after given a continuous daily dose of an antioxidant-rich oral supplement.
<br>
Application of ingredients like almond, chamomile, green tea, and other botanical sources can also provide skin caring benefits. Natural oils are packed with antibacterial, anti-inflammatory, and other properties that help prevent and treat skin issues.
    <br>        </p>
            </li>
            <li><h3>
                Cleansing before bed
            </h3>
            <p>
                 An essential part of any skin care routine is cleansing. Since ancient times, people have been cleaning their skin to improve its health and appearance. While the methods of cleansing have changed, the basic principle remains the same – your skin needs cleaning.
<br>
You may not be aware of it, but your makeup is a carrier of free radicals in the environment. Even if you don't wear makeup, skin collects dust and dirt throughout the day that sit on skin along with your sweat and sebum.
<br>
When you fail to clean skin before going to bed, your skin is basically “sleeping with” free radicals. Exposure to free radicals damages the healthy collagen in your skin resulting in fine lines and wrinkles.
<br>
Apart from subjecting your skin to the damage, your facial pores can also get clogged because of makeup and oils. When this happens, your skin becomes susceptible to acne break outs, enlarged pores and other skin issues.
<br>
Facial cleansing is crucial to maintaining healthy and flawless complexion. So, the next time you are tempted to sleep with your makeup on, think about the harmful consequences and grab your facial cleanser or at least micellar water or a face cleansing wipe.
    <br>        </p>
            </li>
            <li>
                <h3>
                 Get enough sleep   
                </h3>
                <p>
                    Getting enough sleep (at least 7 hours) and not merely sleeping should be an important component of your skin care habits. Whether you have read studies or not, the link between good sleep and skin condition is obvious. Try sleeping just a few hours each night and you will soon feel and see negative changes in your complexion.
<br>
The strong association between getting enough sleep and skin condition was stressed even further by the results of a study on common sleep disorders and dermatological conditions. The same revealed that people who suffer from sleep disorders are more susceptible to experiencing skin disorders like eczema, psoriasis, and skin aging.
<br>
Sleeping is important for a healthy complexion because it is only during deep and prolonged sleep can your cells regenerate, and damaged cells get repaired. Interrupting this process means your skin hardly regenerates, resulting in visible signs of aging skin. Give your skin a chance to stay young by getting your beauty rest.
    <br>            </p>
            </li>
            <li>
                <h3>
                    Manage your stress
                </h3>
                <p>
                    Psychological stress is one of the leading causes of many illnesses and negatively affects your skin condition. When you are stressed, your body activates “emergency” physiological responses to help you cope. Unfortunately, prolonged activation of these responses can result in skin aging, among others.
<br>
A study on published on Dermatology Online Journal revealed that psychological stress is directly linked to skin aging. Stress causes a dysfunction of the immune system, damage to DNA, as well as endocrine and immune modulation – all of which contribute to skin aging.
<br>
Apart from skin aging, your skin also becomes more susceptible to microbial infection when you’re constantly stressed. One clinical investigation showed that stress disturbs the antimicrobial function of the epidermis or the outer layer of the skin. Because of the disruption of the skin’s defense system, it becomes prone to infection.
<br>
Prevent all these negative effects from happening by including stress management in your skin care routine. Do breathing exercises, listen to music, or try aromatherapy to relieve yourself from stress. Topical application of essential oils like sweet almond and chamomile can also help you in this area.
    <br>            </p>
            </li>
            <li>
                <h3>
                    Use a moisturizer            
                </h3>
                <p>
                    Some people think that applying a moisturizer is mainly for aesthetic purposes when in fact, it is a vital part of skin care. Your skin is the most exposed part of your body and this exposure can lead to dryness and loss of moisture.
<br>
Applying moisturizer is needed to replenish the skin’s lost moisture and natural oils, especially after cleansing, toning, or exfoliating. Skin that is well-moisturized is soft, smooth, brighter, and more youthful-looking. Skin that is lacking in moisture, on the other hand, is dry, dull, and scaly – in other words, unattractive.
<br>
If you are hesitant to include moisturizing in your daily skin care regimen because you have oily skin or live in a humid environment, note that dermatologists say you still should. However, instead of using moisturizing products that are cream based, opt for a lighter lotion or serum with humectants like hyaluronic acid. For added protection, use a moisturizer with sunscreen.
    <br>            </p>
            </li>
            <li>
                <h3>
                Keep your body moving            
                </h3>
                <p>
                    While exercise is more commonly associated with losing weight, more and more people are discovering how it promotes healthy and youthful-looking skin. If you doubt this fact, just observe athletes or those who live an active lifestyle; don’t they look much younger and have better skin?
<br>
Exercise aids in better blood circulation. When you walk, jog, or dance, your body increases its blood flow. When this happens the nutrients in the blood are better delivered to your skin cells, which mean your skin becomes well-nourished. Moreover, the efficient blood flow aids in detoxifying your system resulting in a better complexion.
<br>
If in case you suffer from skin inflammatory diseases like eczema and psoriasis, you should take extra precaution when exercising because the increase in your body temperature can exacerbate your condition. To avoid discomfort, make sure to exercise in a cool environment like an air-conditioned gym or jogging at night instead of daytime. Avoid swimming as well since the chlorine in the water can aggravate some of your symptoms.
    <br>            </p>
            </li>
            <li>
                <h3>
        Use skin products made from natural ingredients            
                </h3>
                <p>
                    Your daily skin care regimen will never be complete without skin care products. Contrary to what many people believe, everyone needs and uses such products whether they are aware of it or not. When using skin products, be sure that they contain mostly natural ingredients.
    <br>           

Skin care products made from botanical ingredients are safe, provide anti-aging, anti-inflammatory, and antibacterial benefits, and are even earth-friendly. On the other hand, products that contain mostly man-made chemicals like parabens, sulfates, pthalates and formaldehyde can trigger skin conditions and damage your skin.
    <br>            

To ensure that you will only be using skin care products derived from nature, make it a habit to read the label. If you notice toxic chemicals in the ingredients list, avoid the product at all cost.
              <br>  </p>
            </li>
           
        </ol>
        <p>
            All the basic skin care tips mentioned above may appear too mundane to make an impact, but they are backed up by science. If you think you might be willing to undergo painful dermatological procedures just to get more youthful-looking skin, why not try these simple things that can help you achieve the same results?
<br>
Even Hollywood celebrities vow that the above-mentioned skin care routine works. However, note that the skin-improving effects can only be experienced if you make these habits part of your daily beauty routine. Ultimately, when it comes to skin care, consistency is always the key!
        </p>
    </main>
    <br>
    <center><div class="fb-like" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div></center>
    <center><div class="fb-comments" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-numposts="10" data-width=""></div></center>
    <footer>
        <h3>Health & Lifestyle</h3>
    </footer>
    
     

</body>
</html>