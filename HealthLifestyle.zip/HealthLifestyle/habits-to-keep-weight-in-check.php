<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Health & Lifestyle</title>
    
    <link rel = "stylesheet" href = "home2.css">
    <link rel = "stylesheet" href = "normalize.css">
     <link rel = "stylesheet" href = "content.css">
    
</head>

    
<body class="center">
    
    <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
    
    <div class="headersection">
       
        
           <nav id="hor_menu">
            <ul class="hor_menu_ul">
                <li><a href="Health&Travel.html" class="current"><b>HOME</b></a></li>
                <li><a href="health.html"><b>HEALTH</b></a></li>
                <li><a href="fitness.html"><b>FITNESS</b></a></li>
                <li><a href="Calculator.html"><b>B.M.R CALCULATOR </b></a></li>
                <li><a href="login.php"><b>SIGNOUT</b></a></li>
            </ul>
        </nav>
            
            <div id="heading">
                <h1><b>Health & Lifestyle</b></h1>
            </div>
            
         
            
    </div>
    <main>
       <h1>Ten habits to keep your weight in check</h1>
       <img src="healthyliving.webp" width = "70%;" height="500px;">
       <p>
           Most people who diet will regain 50% of the lost weight in the first year after losing it. Much of the rest will regain it in the following three years.
<br>
Most people inherently know that keeping a healthy weight boils down to three things: eating healthy, eating less, and being active. But actually doing that can be tough.
<br>
We make more than 200 food decisions a day, and most of these appear to be automatic or habitual, which means we unconsciously eat without reflection, deliberation or any sense of awareness of what or how much food we select and consume. So often habitual behaviours override our best intentions.
<br>
A new study has found the key to staying a healthy weight is to reinforce healthy habits.
    <br>   </p>
       <h2>What the new study found</h2>
       <p>
           Imagine each time a person goes home in the evening, they eat a snack. When they first eat the snack, a mental link is formed between the context (getting home) and their response to that context (eating a snack). Every time they subsequently snack in response to getting home, this link strengthens, to the point that getting home prompts them to eat a snack automatically. This is how a habit forms.
<br>
New research has found weight-loss interventions that are founded on habit-change, (forming new habits or breaking old habits) may be effective at helping people lose weight and keep it off.
<br>
We recruited 75 volunteers from the community (aged 18-75) with excess weight or obesity and randomised them into three groups. One program promoted breaking old habits, one promoted forming new habits, and one group was a control (no intervention).
<br>
The habit-breaking group was sent a text message with a different task to perform every day. These tasks were focused on breaking usual routines and included things such as “drive a different way to work today”, “listen to a new genre of music” or “write a short story”.
<br>
The habit-forming group was asked to follow a program that focused on forming habits centred around healthy lifestyle changes. The group was encouraged to incorporate ten healthy tips into their daily routine, so they became second-nature.
    <br>
       After 12 weeks, the habit-forming and habit-breaking participants had lost an average of 3.1kg. More importantly, after 12 months of no intervention and no contact, they had lost another 2.1kg on average.
<br>
Some 67% of participants reduced their total body weight by over 5%, decreasing their overall risk for developing type two diabetes and heart disease. As well as losing weight, most participants also increased their fruit and vegetable intake and improved their mental health.
<br>
Habit-based interventions have the potential to change how we think about weight management and, importantly, how we behave. <br>  </p>
       <h2>Ten healthy habits you should form</h2>
       <p>The habits in the habit-forming group, developed by Weight Concern (a UK charity) were:</p>
       <ol>
           <li>
               keep to a meal routine: eat at roughly the same times each day. People who succeed at long term weight loss tend to have a regular meal rhythm (avoidance of snacking and nibbling). A consistent diet regimen across the week and year also predicts subsequent long-term weight loss maintenance
           </li>
           
           <li>
               go for healthy fats: choose to eat healthy fats from nuts, avocado and oily fish instead of fast food. Trans-fats are linked to an increased risk of heart-disease
           </li>
           <li>
             walk off the weight: aim for 10,000 steps a day. Take the stairs and get off one tram stop earlier to ensure you’re getting your heart rate up every day
           </li>
           <li>
               pack healthy snacks when you go out: swap crisps and biscuits for fresh fruit
           </li>
           <li>
               always look at the labels: check the fat, sugar and salt content on food labels
           </li>
           <li>
               caution with your portions: use smaller plates, and drink a glass of water and wait five minutes then check in with your hunger before going back for seconds
           </li>
           <li>
               break up sitting time: decreasing sedentary time and increasing activity is linked to substantial health benefits. Time spent sedentary is related to excess weight and obesity, independent of physical activity level
           </li>
           <li>
               think about your drinks: choose water and limit fruit juice to one small glass per day
           </li>
           <li>
               focus on your food: slow down and eat while sitting at the table, not on the go. Internal cues regulating food intake (hunger/fullness signals) may not be as effective while distracted
           </li>
           <li>
               always aim for five serves of vegetables a day, whether fresh, frozen or tinned: fruit and vegetables have high nutritional quality and low energy density. Eating the recommended amount produces health benefits, including reduction in the risk of cancer and coronary heart disease.
           </li>
           
       </ol>
      
    </main>
    <br>
    <center><div class="fb-like" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div></center>
    <center><div class="fb-comments" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-numposts="10" data-width=""></div></center>
    <footer>
        <h3><a href="Health&Travel.html">Health & Lifestyle</a></h3>
    </footer>
    
     

</body>
</html>