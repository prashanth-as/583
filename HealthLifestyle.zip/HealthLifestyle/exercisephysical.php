<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Health & Lifestyle</title>
    
    <link rel = "stylesheet" href = "home2.css">
    <link rel = "stylesheet" href = "normalize.css">
     <link rel = "stylesheet" href = "content.css">
    
</head>

    
<body class="center">
   
   
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
    
    <div class="headersection">
       
        
           <nav id="hor_menu">
            <ul class="hor_menu_ul">
                <li><a href="Health&Travel.html" class="current"><b>HOME</b></a></li>
                <li><a href="health.html"><b>HEALTH</b></a></li>
                <li><a href="fitness.html"><b>FITNESS</b></a></li>
                <li><a href="Calculator.html"><b>B.M.R CALCULATOR </b></a></li>
                <li><a href="login.php"><b>SIGNOUT</b></a></li>
            </ul>
        </nav>
            
            <div id="heading">
                <h1><b>Health & Lifestyle</b></h1>
            </div>
            
         
            
    </div>    <main>
       <h1>Excercise vs Physical Activity.</h1><br>
       <img src="excer.jpg" width = "70%;" height="500px;">
<br><br>
        <p>
            Physical activity is defined as movement that involves contraction of your muscles. Any of the activities we do throughout the day that involve movement — housework, gardening, walking, climbing stairs — are examples of physical activity.

<br><br>

            Exercise is a specific form of physical activity — planned, purposeful physical activity performed with the intention of acquiring fitness or other health benefits, says David Bassett, Jr., PhD, a professor in the department of exercise, sport, and leisure studies at the University of Tennessee, Knoxville. Working out at a health club, swimming, cycling, running, and sports, like golf and tennis, are all forms of exercise.
        </p>
<br><br>
        <ol>
            <li><h3>Physical Activity and Exercise: Understanding the Difference.</h3>
            <p>Most daily physical activity is considered light to moderate in intensity. There are certain health benefits that can only be accomplished with more strenuous physical activity, however. Improvement in cardiovascular fitness is one example. Jogging or running provides greater cardiovascular benefit than walking at a leisurely pace, for instance. Additionally, enhanced fitness doesn't just depend of what physical activity you do, it also depends on how vigorously and for how long you continue the activity. That’s why it’s important to exercise within your target heart rate range when doing cardio, for example, to reach a certain level of intensity.<br><br></p>
            </li>
            <li><h3>Physical Activity and Exercise: Understanding Intensity.</h3>
            <p>
                 How can you tell if an activity is considered moderate or vigorous in intensity? If you can talk while performing it, it's moderate. If you need to stop to catch your breath after saying just a few words, it's vigorous. Depending on your fitness level, a game of doubles tennis would probably be moderate in intensity, while a singles game would be more vigorous. Likewise, ballroom dancing would be moderate, but aerobic dancing would be considered vigorous. Again, it's not just your choice of activity, it's how much exertion it requires.<br><br>
            </p>
            </li>
            
    </main>
    <br>
    <center><div class="fb-like" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div></center>
    <center><div class="fb-comments" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-numposts="10" data-width=""></div></center>
    <footer>
    
        <h3><a href="Health&Travel.html">Health & Lifestyle</a></h3>
    </footer>
    
     

</body>
</html>