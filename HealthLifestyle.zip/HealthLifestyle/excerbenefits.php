<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Health & Lifestyle</title>
    
    <link rel = "stylesheet" href = "home2.css">
    <link rel = "stylesheet" href = "normalize.css">
     <link rel = "stylesheet" href = "content.css">
    
</head>

    
<body class="center">
   
   
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
    
    <div class="headersection">
       
        
           <nav id="hor_menu">
            <ul class="hor_menu_ul">
                <li><a href="Health&Travel.html" class="current"><b>HOME</b></a></li>
                <li><a href="health.html"><b>HEALTH</b></a></li>
                <li><a href="fitness.html"><b>FITNESS</b></a></li>
                <li><a href="Calculator.html"><b>B.M.R CALCULATOR </b></a></li>
                <li><a href="login.php"><b>SIGNOUT</b></a></li>
            </ul>
        </nav>
            
            <div id="heading">
                <h1><b>Health & Lifestyle</b></h1>
            </div>
            
         
            
    </div>
    <main>
       <h1>The Lifelong Benefits of Exercise.</h1><br>
       <img src="benefits.jpg" width = "70%;" height="500px;">
<br><br>

        <ol>
            <li><h3>Physical Fitness: What the Benefits of Exercise Mean for You.</h3>
            <p>There's more good news. Research also shows that exercise enhances sleep, prevents weight gain, and reduces the risk of high blood pressure, stroke, type 2 diabetes, and even depression.
<br><br>
            "One study found that when breast cancer survivors engaged in exercise, there were marked improvements in physical activity, strength, maintaining weight, and social well-being," explains Rachel Permuth-Levine, PhD, deputy director for the Office of Strategic and Innovative Programs at the National Heart, Lung, and Blood Institute of the National Institutes of Health.
<br><br>
            "Another study looked at patients with stable heart failure and determined that exercise relieves symptoms, improves quality of life, reduces hospitalization, and in some cases, reduces the risk of death," adds Dr. Permuth-Levine. She points out that exercise isn't just important for people who are already living with health conditions: "If we can see benefits of moderate exercise in people who are recovering from disease, we might see even greater benefits in those of us who are generally well."<br><br></p>
            </li>
            <li><h3>Physical Fitness: Making Exercise a Habit.</h3>
            <p>
            The number one reason most people say they don't exercise is lack of time. If you find it difficult to fit extended periods of exercise into your schedule, keep in mind that short bouts of physical activity in 10-minute segments will nonetheless help you achieve health benefits. Advises Permuth-Levine, "Even in the absence of weight loss, relatively brief periods of exercise every day reduce the risk of cardiovascular disease."
<br><br>
            Set realistic goals and take small steps to fit more movement into your daily life, such as taking the stairs instead of the elevator and walking to the grocery store instead of driving. "The key is to start gradually and be prepared," says Permuth-Levine. "Have your shoes, pedometer, and music ready so you don't have any excuses."
<br><br>
            To help you stick with your new exercise habit, vary your routine, like swimming one day and walking the next. Get out and start a baseball or soccer game with your kids. Even if the weather doesn't cooperate, have a plan B — use an exercise bike in your home, scope out exercise equipment at a nearby community center, or consider joining a health club. The trick is to get to the point where you look at exercise like brushing your teeth and getting enough sleep — as essential to your well-being.
<br><br>
            Remember that physical fitness is attainable. Even with small changes, you can reap big rewards that will pay off for years to come.<br><br>
            </p>
            </li>
            
    </main>
    <br>
    <center><div class="fb-like" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div></center>
    <center><div class="fb-comments" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-numposts="10" data-width=""></div></center>
    <footer>
    
        <h3>Health & Lifestyle</h3>
    </footer>
    
     

</body>
</html>