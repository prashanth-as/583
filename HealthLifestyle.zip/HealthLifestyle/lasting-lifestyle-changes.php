<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Health & Lifestyle</title>
    
    <link rel = "stylesheet" href = "home2.css">
    <link rel = "stylesheet" href = "normalize.css">
     <link rel = "stylesheet" href = "content.css">
    
</head>

    
<body class="center">
   
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
    
    <div class="headersection">
       
        
           <nav id="hor_menu">
            <ul class="hor_menu_ul">
                <li><a href="Health&Travel.html" class="current"><b>HOME</b></a></li>
                <li><a href="health.html"><b>HEALTH</b></a></li>
                <li><a href="fitness.html"><b>FITNESS</b></a></li>
                <li><a href="Calculator.html"><b>B.M.Rs CALCULATOR </b></a></li>
                <li><a href="login.php"><b>SIGNOUT</b></a></li>
            </ul>
        </nav>
            
            <div id="heading">
                <h1><b>Health & Lifestyle</b></h1>
            </div>
            
         
            
    </div>    <main>
       <h1>The trick to real and lasting lifestyle changes</h1>
       <img src="lifestylechanges.jpg" width = "70%;" height="500px;">
        <p>
            Regardless of the time of year that we decide to eat better, exercise more, or be less stressed, it can be hard to make a lifestyle change, and even harder to make it stick.
<br><br>
But there is a way to up your chances of success.
<br><br>
Experts say efforts to make lifestyle changes are more likely to produce results if they are SMART — that is, specific, measurable, achievable, realistic, and time-based. If you're thinking of making a change, see if your goal can pass the SMART test:</p>
       
       <ol>
           <li>
               <p>
                   Set a very specific goal. For example: I will add one fruit serving — that's half a cup, chopped — to my current daily diet.
               </p>
           </li>
           <li>
               <p>
                   Find a way to measure progress. For example, I will log my efforts each day on my calendar.
               </p>
           </li>
           <li>
               <p>
                   Make sure it's achievable. For example, don't set a goal of a daily 5 mile run if you're out of shape. If you can't safely or reasonably accomplish your goal, set a smaller, achievable one.
               </p>
           </li>
           <li>
               <p>
                   Make sure it's realistic. It may seem counterintuitive, but choosing the change you most need to make — let's say, quitting smoking or losing weight — isn't as successful as choosing the change you're most confident you'll be able to make. Focus on sure bets: if you picture a 10-point scale of confidence in achieving your goal, where 1 equals no confidence and 10 equals 100% certainty, you should land in the 7-to-10 zone. An additional fruit serving a day is a small, manageable step toward better health.
               </p>
           </li>
           <li>
               <p>
                   Set time commitments. Pick a date and time to start. For example, Wednesday at breakfast, I'll add frozen blueberries to cereal. Pick and regular check-in dates: I'll check my log every week and decide if I should make any changes in my routines to succeed. Find an outside deadline that will help keep you motivated. For example, signing up for a charity run or sprint triathlon on a certain date prods you to get a training program under way.
               </p>
           </li>
       </ol>
        <p>Making a change can be daunting, but it doesn't have to be. Get the Special Health Report, Simple Changes, Big Rewards: A practical, easy guide for healthy, happy living to learn how to incorporate simple changes into your life that can reap big rewards.</p>
    </main>
    <br>
    <center><div class="fb-like" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div></center>
    <center><div class="fb-comments" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-numposts="10" data-width=""></div></center>
    <footer>
        
           <h3>Health & Lifestyle</h3> 
        
    </footer>
    
     

</body>
</html>