var $ = function (id) {
    return document.getElementById(id);
};


var calculateCalories = function () {
	var age = $("age").value;
	var feet = $("feet").value;
	var inches = $("inches").value;
    var weight = $("weight").value;
    var isValid = true;
    var sexOptions = document.getElementsByName("sex");
    var sex;
    
            for(i = 0; i < sexOptions.length; i++) { 
                if(sexOptions[i].checked) 
                sex = sexOptions[i].value;
            } 
  
	var activityOptions = document.getElementsByName("activity");
    var activitylevel;
            for(i =0; i < activityOptions.length; i++){
                if(activityOptions[i].checked)
                activitylevel = activityOptions[i].value;
            }
    
	if (age === "") 
    { 
		$("age_error").firstChild.nodeValue = "*Required";
		isValid = false;
	} 
    else { $("age_error").firstChild.nodeValue = ""; } 


	if (feet === "") 
    {
		$("height_error").firstChild.nodeValue = "*Required";
		isValid = false;
	} 
    else { $("height_error").firstChild.nodeValue = ""; }  
    
	if (weight === "") 
    {
		$("weight_error").firstChild.nodeValue = "*Required";
		isValid = false;
	} 
    else { $("weight_error").firstChild.nodeValue = ""; } 
    
   if(sex == undefined)
    {   
        $("sex_error").firstChild.nodeValue = "*Required";
		isValid = false;
	}
    else { $("sex_error").firstChild.nodeValue = ""; } 
    
    if(activitylevel == undefined)
    {   
        $("activity_error").firstChild.nodeValue = "*Required";
		isValid = false;
	}
    else { $("activity_error").firstChild.nodeValue = ""; } 
    
     /* if(sexOptions[0].checked == true){
        sex = "M";
    }
    else if(sexOptions[1].checked == true){
        sex = "F";
    }
    else{
        alert("Please select value for sex");
         /*$("sex_error").firstChild.nodeValue = "*Required.";
		isValid = false;
    }*/
  
    /*Calculating bmr*/
    var bmr;
    var dailyCalories;
    var height = parseInt(feet*12) + parseInt(inches);
    if(sex == "F"){
        
        bmr = 655 + (4.35 * weight) + (4.7 * height) - (4.7 * age);
    
    }
    if(sex == "M"){
        
        bmr = 66 + (6.23 * weight) + (12.7 * height) - (6.8 * age);
    }
    
    
    
    /*Calculating calories*/
    if(activitylevel == "inactive"){
        dailyCalories = 1.2 * bmr;
    }
    if(activitylevel == "somewhatactive"){
        dailyCalories = 1.375 * bmr;
    }
    if(activitylevel == "active"){
        dailyCalories = 1.55 * bmr;
    }
    if(activitylevel == "veryactive"){
        dailyCalories = 1.725 * bmr;
    }

    
    /*displaying calories on screen*/
    var resultpage = $("resultpage");
    $("calories_result").innerHTML = "Your total calorie needs: " + dailyCalories.toFixed(0);
    $("bmr").innerHTML = "Basal Metabolic Rate (BMR): " + bmr.toFixed(0) ;
    resultpage.scrollIntoView();
};



window.onload = function() {
 
    $("calculate").onclick = calculateCalories;
   
};