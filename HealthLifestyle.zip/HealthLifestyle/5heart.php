<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Health & Lifestyle</title>
    
    <link rel = "stylesheet" href = "home2.css">
    <link rel = "stylesheet" href = "normalize.css">
     <link rel = "stylesheet" href = "content.css">
    
</head>

    
<body class="center">
   
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   <div id="fb-root"></div>
<script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v6.0"></script>
   
    
    <div class="headersection">
       
        
           <nav id="hor_menu">
            <ul class="hor_menu_ul">
                <li><a href="Health&Travel.html" class="current"><b>HOME</b></a></li>
                <li><a href="health.html"><b>HEALTH</b></a></li>
                <li><a href="fitness.html"><b>FITNESS</b></a></li>
                <li><a href="Calculator.html"><b>B.M.R CALCULATOR </b></a></li>
                <li><a href="login.php"><b>SIGNOUT</b></a></li>
            </ul>
        </nav>
            
            <div id="heading">
                <h1><b>Health & Lifestyle</b></h1>
            </div>
            
         
            
    </div>
    <main>
       <h1>5 things to do everyday to keep your heart healthy</h1>
       <img src="nicola-fioravanti-MryBlxc2ocw-unsplash.jpg" width = "70%;" height="500px;">
        <p>
            You know that exercise and a good diet can keep your heart healthy. But what else can you do to keep your ticker going strong? Here, Marc Gillinov, MD, Chair of Cleveland Clinic’s Department of Thoracic and Cardiovascular Surgery, recommends five key things you need to do every day to help your heart work most efficiently. Incorporate these habits into your lifestyle and your heart health will be the best it can be for you.
        </p>
        
        <ol>
            <li><h3>Eat healthy fats, NOT trans fats.</h3>
            <p>We need fats in our diet, including saturated and polyunsaturated and unsaturated fats. One fat we don’t need is trans fat, which is known to increase your risk of developing heart disease or having a stroke over a lifetime. This is because trans fat clogs your arteries by raising your bad cholesterol levels (LDL) and lowering your good cholesterol levels (HDL). By cutting them from your diet, you improve the blood flow throughout your body. So, what are trans fats? They are industry-produced fats often used in packaged baked goods, snack foods, margarines and fried fast foods to add flavor and texture.<br><br><b>TIP: </b>Read the labels on all foods. Trans fat appears on the ingredients list as partially hydrogenated oils. Look for 0 percent trans fat. Make it a point to avoid eating foods with trans fat.</p>
            </li>
            <li><h3>Practice good dental hygiene, especially flossing your teeth daily.</h3>
            <p>
                 Dental health is a good indication of overall health, including your heart, because those who have periodontal (gum) disease often have the same risk factors for heart disease. Studies continue on this issue, but many have shown that bacteria in the mouth involved in the development of gum disease can move into the bloodstream and cause an elevation in C-reactive protein, a marker for inflammation in the blood vessels. These changes may in turn, increase your risk of heart disease and stroke.<br><br><b>TIP: </b> Floss and brush your teeth daily to ward off gum disease. It’s more than cavities you may have to deal with if you are fighting gum disease.
            </p>
            </li>
            <li><h3>
                Get enough sleep.
            </h3>
            <p>
                Sleep is an essential part of keeping your heart healthy. If you don’t sleep enough, you may be at a higher risk for cardiovascular disease no matter your age or other health habits. One study looking at 3,000 adults over the age of 45 found that those who slept fewer than six hours per night were about twice as likely to have a stroke or heart attack as people who slept six to eight hours per night. Researchers believe sleeping too little causes disruptions in underlying health conditions and biological processes, including blood pressure and inflammation.<br><br><b>TIP:</b> Make sleep a priority. Get 7 to 8 hours of sleep most nights. If you have sleep apnea, you should be treated as this condition is linked to heart disease and arrhythmias.
            </p>
            </li>
            <li><h3>
                Don’t sit for too long at one time.
            </h3>
            <p>
                In recent years, research has suggested that staying seated for long periods of time is bad for your health no matter how much exercise you do. This is bad news for the many people who sit at sedentary jobs all day. When looking at the combined results of several observational studies that included nearly 800,000 people, researchers found that in those who sat the most, there was an associated 147 percent increase in cardiovascular events and a 90 percent increase in death caused by these events. In addition, sitting for long periods of time (especially when traveling) increases your risk of deep vein thrombosis (a blood clot).<br><br><b>TIP:</b> Experts say it’s important to move throughout the day. Park farther away from the office, take a few shorter walks throughout the day and/or use a standing work station so you can move up and down. And remember to exercise on most days.
            </p>
            </li>
            <li><h3>
                Avoid secondhand smoke like the plague.
            </h3>
            <p>
                 Studies show that the risk of developing heart disease is about 25 to 30 percent higher for people who are exposed to secondhand smoke at home or work. According to the American Heart Association, exposure to tobacco smoke contributes to about 34,000 premature heart disease deaths and 7,300 lung cancer deaths each year. And nonsmokers who have high blood pressure or high blood cholesterol have an even greater risk of developing heart disease when they’re exposed to secondhand smoke. This is because the chemicals emitted from cigarette smoke promote the development of plaque buildup in the arteries.<br><br><b>TIP: </b>Be firm with smokers that you do not want to be around environmental smoke — and keep children away from secondhand smoke. 
            </p>
            </li>
        </ol>
        <p>
            Follow these five tips and you’ll be doing your heart a favor. You’ll feel better and be able to stay active with a heart-healthy lifestyle.
        </p>
    </main>
<br>
    <center><div class="fb-like" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-width="" data-layout="button_count" data-action="like" data-size="large" data-share="true"></div></center>
    <center><div class="fb-comments" data-href="<?php echo "http://" . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" data-numposts="10" data-width=""></div></center>
    
       
    <footer>
        <h3><a href="Health&Travel.html">Health & Lifestyle</a></h3>
    </footer>
    
     

</body>
</html>