<!--
Into this file, we create a layout for login page.
-->

<?php
include_once('link.php');
?>
<style>
<?php include 'logreg.css'; ?>
</style>

<body>
<div class="container" id="container">
	<div class="form-container sign-up-container">
		<form action="registration_code.php" method="POST">
			<h1>Create Account</h1>
			<input type="text" name="firstname" required id="firstname" placeholder="Enter Firstname">
            <input type="text" name="lastname" required id="lastname" placeholder="Enter Lastname">
            <input type="email" name="email" required id="email" placeholder="Enter email">
            <input type="password" name="password" required id="pwd" placeholder="Enter password">
			<button>Sign Up</button>
		</form>
	</div>
	<div class="form-container sign-in-container">
		<form method="POST" action="login_code.php">
			<h1>Sign in</h1>
			<input type="email" name="email" required id="email" placeholder="Email" />
			<input type="password" name="password" required id="pwd" placeholder="Password" />
			<button>Sign In</button>
		</form>
	</div>
	<div class="overlay-container">
		<div class="overlay">
			<div class="overlay-panel overlay-left">
				<h1>Already with us?</h1>
				<p>Login to continue to the website.</p>
				<button class="ghost" id="signIn">Sign In</button>
			</div>
			<div class="overlay-panel overlay-right">
                <h1>Welcome to health & lifestyle.</h1>
				<p>Don't have an account? <br>Enter your details and get started.</p>
				<button class="ghost" id="signUp">Sign Up</button>
			</div>
		</div>
	</div>
</div>
<script type="text/javascript" src="logregs.js"></script>
</body>
