$(document).ready(function() 
                  
{
  
/* --- To get the focus to arrival date box : ---  */
    
$("#arrival_date").focus(); 
    

/* --- Validation for the reservation form : ---  */
    
	$("#reservation_form").submit(
		
        function(event) {
			
            var validation = true;
                       
/* --- Validation for General Information : ---  */
            
  
/* --- Validation for the arrival date : --- */
            
            var DateOfArrival = $("#arrival_date").val().trim();
			
            if (DateOfArrival == "") // if the value is null, print the following : 
            {
				$("#arrival_date").next().text("This field is required.");
				validation = false;
			} 
            else 
            {
				$("#arrival_date").next().text("");
			}
			
            $("#arrival_date").val(DateOfArrival);
            
            
 /* --- Validation for nights : --- */
            
            var nightsnumeric = /[1-9]/g;
            
            var nightss = Number($("#nights").val());
            
            if (nightss == "") // if the value is null, print the following : 
            { 
				$("#nights").next().text("This field is required.");
				validation = false; 
			} 
            else if ( !nightsnumeric.test(nightss) ) // if not, check if the nights are numeric
            {
				$("#nights").next().text("Enter Numeric Values");
				validation = false;
			} 
            else
            {
				$("#nights").next().text("");
			}
			
            $("#nights").val(nightss);   
            
            
/* --- Validation for Contact Information : ---  */
            
            
/* --- Validation for name : --- */
            
			var username = $("#name").val().trim();
			
            if (username == "") // if the value is null, print the following : 
            {
				$("#name").next().text("This field is required.");
				validation = false;
			} 
            else 
            {
				$("#name").next().text("");
			}
			
            $("#name").val(username);
            
            
/* --- Validation for email null & email pattern : --- */
            
            
			var emailPattern = /\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,4}\b/;
			
            var userEmail = $("#email").val().trim();
			
            if (userEmail == "")  // if the value is null, print the following : 
            { 
				$("#email").next().text("This field is required.");
				validation = false;
			} 
            else if ( !emailPattern.test(userEmail) ) // if not, check if the pattern is same as given :
            {
				$("#email").next().text("Enter in this format : abc@xyz.com. ");
				validation = false;
			} 
            else 
            {
				$("#email").next().text("");
			}
			
            $("#email").val(userEmail);
            
                 
/* --- Validation for phone null & phone pattern : --- */
            
            
			var phonePattern = /^\d{3}-\d{3}-\d{4}$/;
            
			var userPhone = $("#phone").val().trim();
			
            if (userPhone == "")  // if the value is null, print the following : 
            { 
				$("#phone").next().text("This field is required.");
				validation = false; 
			} 
            else if ( !phonePattern.test(userPhone) ) // if not, check if the pattern is same as given :
            {
				$("#phone").next().text("Enter in this format : 999-999-9999. ");
				validation = false;
			} 
            else 
            {
				$("#phone").next().text("");
			}
			$("#phone").val(userPhone);   
                
 
			if (validation == false) {
				event.preventDefault();	
            }
        }
    );
}); 