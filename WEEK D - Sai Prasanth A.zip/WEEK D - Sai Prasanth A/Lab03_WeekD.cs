﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab03_WeekD
{
    class Program
    {
        static void Main(string[] args)
        {
            double CurBal = 45.32;

            double Amount;
            Console.Write("Please enter a amount to update account by $");
            Amount = Double.Parse(Console.ReadLine());
            Console.WriteLine();

            Console.Write("Customer's balance (before transaction) = $");
            Console.WriteLine(CurBal + "\n");
            Console.Write("Requested update amount = $");
            Console.WriteLine(Amount + "\n");

            double ActAmount;
            ActAmount = Transaction(CurBal, Amount);
            CurBal += ActAmount;

            Console.Write("Actual update amount = $");
            Console.WriteLine(ActAmount + "\n");
            Console.Write("Customer's balance (after transaction) = $");
            Console.WriteLine(CurBal + "\n");

            Console.WriteLine("\nThank you and good-bye!\n");

            
            Console.Read();
        }

        public static double Transaction(double bal, double amount)
        {
            return bal + amount < 0 ? -bal : amount;
        }
    }
}