var $ = function(id) {
    return document.getElementById(id);
};

// This function takes the values from html inputs and assigns them to variables :

    var joinList = function() {
	var emailAddress1 = $("email_address1").value;
	var emailAddress2 = $("email_address2").value;
	var isValid = true;


// This checks whether the email address is null or not by asking this condition : emailAddress1 === "" and if it's null, it gives the specified error msg : ""
	
	if (emailAddress1 === "") { 
		$("email_address1_error").firstChild.nodeValue = "This field is required.";
		isValid = false;
	} else { $("email_address1_error").firstChild.nodeValue = ""; } 

// This checks whether the first feild matches the secodn feild entry to check if they're the same, if not gives the specified error msg : 

	if (emailAddress1 !== emailAddress2) { 
		$("email_address2_error").firstChild.nodeValue = "This entry must equal first entry.";
		isValid = false;
	} else { $("email_address2_error").firstChild.nodeValue = ""; }     
// This checks whether the first name value is null or not by asking this condition : $("first_name").value === "" and if it's null, it gives the specified error msg : ""
       
	if ($("first_name").value === "") {
		$("first_name_error").firstChild.nodeValue = 
                        "This field is required.";
		isValid = false;
	} else { $("first_name_error").firstChild.nodeValue = ""; }  

// if everything is fine, it takes submit. here, the initial submit code had a mistake of two 't'. 	
	/* if (isValid) {
		$("email_form").submitt(); 
	} */
        
    if (isValid) {
		$("email_form").submit(); 
	}
};

// This is the code for the 'Join list' button. It triggers the joinlist function we created before. 
window.onload = function() {
    $("join_list").onclick = joinList;
    $("email_address1").focus();
};
