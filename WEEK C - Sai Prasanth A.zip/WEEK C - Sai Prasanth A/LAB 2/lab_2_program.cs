﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week_c_lab_2
{
    class Program
    {
        static void Main(string[] args)
        {
            var GlassesPrices = new Dictionary<int, decimal>();
            GlassesPrices.Add(1, 40);
            GlassesPrices.Add(2, 25);

            var CoatingPrices = new Dictionary<int, decimal>();
            CoatingPrices.Add(1, 12.5M);
            CoatingPrices.Add(2, 9.99M);

            int GlassesSelection;
            int CoatingSelection;

            Console.WriteLine("What kind of glasses would you like:");
            do
            {
                Console.Write("1 : Prescription, 2 : Non Prescription : ");
            }
            while (!Int32.TryParse(Console.ReadLine(), out GlassesSelection) || !GlassesPrices.ContainsKey(GlassesSelection));

            Console.WriteLine("What kind of coating would you like:");
            do
            {
                string Message = "";

                if (!GlassesRequireCoating(GlassesSelection))
                {
                    Message += "0 -> No coating, ";
                }

                Console.Write(Message + "1 : Anti-glare, 2 : Brown tint : ");
            }
            while (!Int32.TryParse(Console.ReadLine(), out CoatingSelection) || !CoatingSelectionIsValid(CoatingSelection, GlassesSelection, CoatingPrices));

            Console.WriteLine($"Your total cost is ${GlassesPrices[GlassesSelection] + (CoatingPrices.ContainsKey(CoatingSelection) ? CoatingPrices[CoatingSelection] : 0)}");

            Console.Read();
        }

        public static bool GlassesRequireCoating(int glasses)
        {
            int[] GlassesRequiringCoating = { 1 };

            return GlassesRequiringCoating.Contains(glasses);
        }

        public static bool CoatingSelectionIsValid(int coatingSelection, int glassesSelection, IDictionary<int, decimal> coatingPrices)
        {
            return GlassesRequireCoating(glassesSelection) ? coatingPrices.ContainsKey(coatingSelection) : true;
        }
    }
}
