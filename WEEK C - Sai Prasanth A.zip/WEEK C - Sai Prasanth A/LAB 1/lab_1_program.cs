﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace week_c_lab_1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
             * Answers to questions from instructions..
             * 
             * 2. Different syntax, but logically equivalent.
             * 
             * 5. Any of the if/else-if/else statements do not need to be written in block form if they only contain one line.
             * So, none of the if/else-if/else statements in this code need to be written in block form.
             */

            Console.WriteLine("CS 201 Restaurant Guide\n");

            string Response;
            char S, F;
            bool Spicy, Fancy;

            // Ask user for his/her preference
            Console.Write("Do you like spicy food? (y / n) : ");
            // Get the next token
            Response = Console.ReadLine();
            // Look only at first character
            S = Response[0];
            if (S.Equals('y') || S.Equals('Y'))
            {
                Spicy = true;
            }
            else
            {
                Spicy = false;
            }

            // Ask user for his/her preference
            Console.Write("Do you want to go to a fancy restaurant? (y / n) : ");
            // Get the next token
            Response = Console.ReadLine();
            // Look only at first character
            F = Response[0];
            Fancy = F.Equals('y') || F.Equals('Y');

            // Make suggestion
            if (Spicy && Fancy)
            {
                Console.WriteLine("I suggest you go to Thai Garden Palace.");
            }
            else
            {
                if (!Spicy && !Fancy)
                {
                    Console.WriteLine("I suggest you go to Joe's Diner.");
                }
                else
                {
                    if (Spicy && !Fancy)
                    {
                        Console.WriteLine("I suggest you go to Alberto's Tacqueria.");
                    }
                    else
                    {
                        if (!Spicy && Fancy)
                        {
                            Console.WriteLine("I suggest you go to Chez Paris.");
                        }
                    }
                }
            }

            // Adding this so the app doesn't exit (even though it's not part of the Java code in the instructions)
            Console.Read();
        }
    }
}
